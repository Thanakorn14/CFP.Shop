function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.push({ name, price });
  localStorage.setItem('cart', JSON.stringify(cart));
  alert('เพิ่มสินค้าลงตะกร้าแล้ว');
}
function displayCart() {
  const items = JSON.parse(localStorage.getItem('cart')) || [];
  const container = document.getElementById('cart-items');
  let total = 0;
  container.innerHTML = '';
  items.forEach(item => {
    const div = document.createElement('div');
    div.textContent = `${item.name} - ${item.price} บาท`;
    total += item.price;
    container.appendChild(div);
  });
  document.getElementById('total-price').textContent = total;
}
function payNow() {
  alert('ชำระเงินเรียบร้อย!');
  localStorage.setItem('cart', '[]');
  const history = JSON.parse(localStorage.getItem('history')) || [];
  history.push({ date: new Date().toLocaleString(), items: [] });
  localStorage.setItem('history', JSON.stringify(history));
  document.getElementById('payment-result').textContent = 'ชำระเงินสำเร็จ';
}
function topUp() {
  const amount = parseFloat(document.getElementById('topup-amount').value);
  let balance = parseFloat(localStorage.getItem('balance')) || 0;
  balance += amount;
  localStorage.setItem('balance', balance);
  document.getElementById('topup-result').textContent = `ยอดเงินคงเหลือ: ${balance} บาท`;
}
function loadHistory() {
  const history = JSON.parse(localStorage.getItem('history')) || [];
  const container = document.getElementById('purchase-history');
  history.forEach(order => {
    const div = document.createElement('div');
    div.textContent = `${order.date}`;
    container.appendChild(div);
  });
}
function login() {
  const user = document.getElementById('username').value;
  localStorage.setItem('user', user);
  document.getElementById('login-result').textContent = 'เข้าสู่ระบบสำเร็จ';
}
function register() {
  login();
}
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('cart-items')) displayCart();
  if (document.getElementById('purchase-history')) loadHistory();
});